/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.content.registry;

import java.util.Map;

import it.unimi.dsi.fastutil.objects.Object2IntLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2609;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

// TODO: Clamp values to 32767 (+ add hook for mods which extend the limit to disable the check?)
public final class FuelRegistryImpl implements FuelRegistry {
	private static final Logger LOGGER = LoggerFactory.getLogger(FuelRegistryImpl.class);
	private final Object2IntMap<class_1935> itemCookTimes = new Object2IntLinkedOpenHashMap<>();
	private final Object2IntMap<class_6862<class_1792>> tagCookTimes = new Object2IntLinkedOpenHashMap<>();

	public FuelRegistryImpl() {
	}

	public Map<class_1792, Integer> getFuelTimes() {
		// Cached by vanilla now
		return class_2609.method_11196();
	}

	@Override
	public Integer get(class_1935 item) {
		return getFuelTimes().get(item.method_8389());
	}

	@Override
	public void add(class_1935 item, Integer cookTime) {
		if (cookTime > 32767) {
			LOGGER.warn("Tried to register an overly high cookTime: " + cookTime + " > 32767! (" + item + ")");
		}

		itemCookTimes.put(item, cookTime.intValue());
		resetCache();
	}

	@Override
	public void add(class_6862<class_1792> tag, Integer cookTime) {
		if (cookTime > 32767) {
			LOGGER.warn("Tried to register an overly high cookTime: " + cookTime + " > 32767! (" + getTagName(tag) + ")");
		}

		tagCookTimes.put(tag, cookTime.intValue());
		resetCache();
	}

	@Override
	public void remove(class_1935 item) {
		add(item, 0);
		resetCache();
	}

	@Override
	public void remove(class_6862<class_1792> tag) {
		add(tag, 0);
		resetCache();
	}

	@Override
	public void clear(class_1935 item) {
		itemCookTimes.removeInt(item);
		resetCache();
	}

	@Override
	public void clear(class_6862<class_1792> tag) {
		tagCookTimes.removeInt(tag);
		resetCache();
	}

	public void apply(Map<class_1792, Integer> map) {
		// tags take precedence before blocks
		for (class_6862<class_1792> tag : tagCookTimes.keySet()) {
			int time = tagCookTimes.getInt(tag);

			if (time <= 0) {
				for (class_6880<class_1792> key : class_7923.field_41178.method_40286(tag)) {
					final class_1792 item = key.comp_349();
					map.remove(item);
				}
			} else {
				class_2609.method_11194(map, tag, time);
			}
		}

		for (class_1935 item : itemCookTimes.keySet()) {
			int time = itemCookTimes.getInt(item);

			if (time <= 0) {
				map.remove(item.method_8389());
			} else {
				class_2609.method_11202(map, item, time);
			}
		}
	}

	private static String getTagName(class_6862<?> tag) {
		return tag.comp_327().toString();
	}

	public void resetCache() {
		// Note: tag reload is already handled by vanilla, see DataPackContents#refresh
		class_2609.method_56120();
	}
}

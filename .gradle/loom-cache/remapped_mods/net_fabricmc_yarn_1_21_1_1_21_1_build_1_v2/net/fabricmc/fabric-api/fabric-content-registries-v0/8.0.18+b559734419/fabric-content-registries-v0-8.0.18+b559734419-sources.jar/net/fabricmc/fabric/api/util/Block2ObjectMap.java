/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.util;

import net.minecraft.class_2248;
import net.minecraft.class_6862;

public interface Block2ObjectMap<V> {
	V get(class_2248 block);

	void add(class_2248 block, V value);

	void add(class_6862<class_2248> tag, V value);

	void remove(class_2248 block);

	void remove(class_6862<class_2248> tag);

	void clear(class_2248 block);

	void clear(class_6862<class_2248> tag);
}

/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.tag;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

/**
 * General-purpose Fabric-provided extensions for {@link class_6862} subclasses.
 *
 * <p>These extensions were designed primarily for giving extra utility methods for TagKeys usages.
 * Getting a TagKey's translation key for example.
 *
 * <p>Note: This interface is automatically implemented on all {@link class_6862} instances via Mixin and interface injection.
 */
public interface FabricTagKey {
	/**
	 * Use this to get a TagKey's translation key safely on any side.
	 *
	 * <p>Format for vanilla registry TagKeys is:
	 * tag.(registry_path).(tag_namespace).(tag_path)
	 *
	 * <p>Format for modded registry TagKeys is:
	 * tag.(registry_namespace).(registry_path).(tag_namespace).(tag_path)
	 *
	 * <p>The registry's path and tag path's slashes will be converted to periods.
	 *
	 * @return the translation key for a TagKey
	 */
	default String getTranslationKey() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("tag.");

		class_6862<?> tagKey = (class_6862<?>) this;
		class_2960 registryIdentifier = tagKey.comp_326().method_29177();
		class_2960 tagIdentifier = tagKey.comp_327();

		if (!registryIdentifier.method_12836().equals(class_2960.field_33381)) {
			stringBuilder.append(registryIdentifier.method_12836())
					.append(".");
		}

		stringBuilder.append(registryIdentifier.method_12832().replace("/", "."))
				.append(".")
				.append(tagIdentifier.method_12836())
				.append(".")
				.append(tagIdentifier.method_12832().replace("/", ".").replace(":", "."));

		return stringBuilder.toString();
	}

	/**
	 * Use this to get a TagKey's translatable text for display purposes.
	 *
	 * <p>The text uses the result of {@link class_6862#getTranslationKey} for the translation key
	 * and will fall back to displaying #tag_namespace:tag_path if no translation exists.
	 *
	 * @return the translatable text for a TagKey
	 */
	default class_2561 getName() {
		return class_2561.method_48321(getTranslationKey(), "#" + ((class_6862<?>) this).comp_327().toString());
	}
}

/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.event.interaction;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2626;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3965;

@Mixin(class_3225.class)
public class ServerPlayerInteractionManagerMixin {
	@Shadow
	protected class_3218 world;
	@Final
	@Shadow
	protected class_3222 player;

	@Inject(at = @At("HEAD"), method = "processBlockBreakingAction", cancellable = true)
	public void startBlockBreak(class_2338 pos, class_2846.class_2847 playerAction, class_2350 direction, int worldHeight, int i, CallbackInfo info) {
		if (playerAction != class_2846.class_2847.field_12968) return;
		class_1269 result = AttackBlockCallback.EVENT.invoker().interact(player, world, class_1268.field_5808, pos, direction);

		if (result != class_1269.field_5811) {
			// The client might have broken the block on its side, so make sure to let it know.
			this.player.field_13987.method_14364(new class_2626(world, pos));

			if (world.method_8320(pos).method_31709()) {
				class_2586 blockEntity = world.method_8321(pos);

				if (blockEntity != null) {
					class_2596<class_2602> updatePacket = blockEntity.method_38235();

					if (updatePacket != null) {
						this.player.field_13987.method_14364(updatePacket);
					}
				}
			}

			info.cancel();
		}
	}

	@Inject(at = @At("HEAD"), method = "interactBlock", cancellable = true)
	public void interactBlock(class_3222 player, class_1937 world, class_1799 stack, class_1268 hand, class_3965 blockHitResult, CallbackInfoReturnable<class_1269> info) {
		class_1269 result = UseBlockCallback.EVENT.invoker().interact(player, world, hand, blockHitResult);

		if (result != class_1269.field_5811) {
			info.setReturnValue(result);
			info.cancel();
			return;
		}
	}

	@Inject(at = @At("HEAD"), method = "interactItem", cancellable = true)
	public void interactItem(class_3222 player, class_1937 world, class_1799 stack, class_1268 hand, CallbackInfoReturnable<class_1269> info) {
		class_1271<class_1799> result = UseItemCallback.EVENT.invoker().interact(player, world, hand);

		if (result.method_5467() != class_1269.field_5811) {
			info.setReturnValue(result.method_5467());
			info.cancel();
			return;
		}
	}

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;onBreak(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Lnet/minecraft/entity/player/PlayerEntity;)Lnet/minecraft/block/BlockState;"), method = "tryBreakBlock", locals = LocalCapture.CAPTURE_FAILHARD, cancellable = true)
	private void breakBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir, class_2586 entity, class_2248 block, class_2680 state) {
		boolean result = PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(this.world, this.player, pos, state, entity);

		if (!result) {
			PlayerBlockBreakEvents.CANCELED.invoker().onBlockBreakCanceled(this.world, this.player, pos, state, entity);

			cir.setReturnValue(false);
		}
	}

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;onBroken(Lnet/minecraft/world/WorldAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;)V"), method = "tryBreakBlock", locals = LocalCapture.CAPTURE_FAILHARD)
	private void onBlockBroken(class_2338 pos, CallbackInfoReturnable<Boolean> cir, class_2586 entity, class_2248 block, class_2680 state, boolean bl) {
		PlayerBlockBreakEvents.AFTER.invoker().afterBlockBreak(this.world, this.player, pos, state, entity);
	}
}

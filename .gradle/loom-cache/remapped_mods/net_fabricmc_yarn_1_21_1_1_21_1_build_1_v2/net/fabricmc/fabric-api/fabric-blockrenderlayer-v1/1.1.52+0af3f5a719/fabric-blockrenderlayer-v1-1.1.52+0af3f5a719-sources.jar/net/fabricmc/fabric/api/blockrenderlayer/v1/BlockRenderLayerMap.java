/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.blockrenderlayer.v1;

import net.fabricmc.fabric.impl.blockrenderlayer.BlockRenderLayerMapImpl;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_3611;
import net.minecraft.class_4696;

/**
 * Use to associate blocks or fluids with block render layer other than default.
 *
 * <p>{@link class_4696} control how sprite pixels for fluids and blocks are blended
 * with the scene. Consult the vanilla {@link class_4696} implementation for examples.
 *
 * <p>The Fabric Renderer API can be used to control this at a per-quad level at the code
 * via {@code BlendMode}.
 *
 * <p>Client-side only.
 */
public interface BlockRenderLayerMap {
	BlockRenderLayerMap INSTANCE = new BlockRenderLayerMapImpl();

	/**
	 * Map (or re-map) a block state with a render layer.  Re-mapping is not recommended but if done, last one in wins.
	 * Must be called from client thread prior to world load/rendering. Best practice will be to call from mod's client initializer.
	 *
	 * @param block Identifies block to be mapped.
	 * @param renderLayer Render layer.  Should be one of the layers used for terrain rendering.
	 */
	void putBlock(class_2248 block, class_1921 renderLayer);

	/**
	 * Map (or re-map) multiple block states with a render layer.  Re-mapping is not recommended but if done, last one in wins.
	 * Must be called from client thread prior to world load/rendering. Best practice will be to call from mod's client initializer.
	 *
	 * @param renderLayer Render layer.  Should be one of the layers used for terrain rendering.
	 * @param blocks Identifies blocks to be mapped.
	 */
	void putBlocks(class_1921 renderLayer, class_2248... blocks);

	/**
	 * @deprecated For blocks, calling {@link #putBlock(class_2248, class_1921)} is enough.
	 * Other items always use a translucent render layer.
	 */
	@Deprecated(forRemoval = true)
	void putItem(class_1792 item, class_1921 renderLayer);

	/**
	 * @deprecated For blocks, calling {@link #putBlocks(class_1921, class_2248...)} is enough.
	 * Other items always use a translucent render layer.
	 */
	@Deprecated(forRemoval = true)
	void putItems(class_1921 renderLayer, class_1792... items);

	/**
	 * Map (or re-map) a fluid state with a render layer.  Re-mapping is not recommended but if done, last one in wins.
	 * Must be called from client thread prior to world load/rendering. Best practice will be to call from mod's client initializer.
	 *
	 * @param fluid Identifies fluid to be mapped.
	 * @param renderLayer Render layer.  Should be one of the layers used for terrain rendering.
	 */
	void putFluid(class_3611 fluid, class_1921 renderLayer);

	/**
	 * Map (or re-map) multiple fluid states with a render layer.  Re-mapping is not recommended but if done, last one in wins.
	 * Must be called from client thread prior to world load/rendering. Best practice will be to call from mod's client initializer.
	 *
	 * @param renderLayer Render layer.  Should be one of the layers used for terrain rendering.
	 * @param fluids Identifies fluids to be mapped.
	 */
	void putFluids(class_1921 renderLayer, class_3611... fluids);
}

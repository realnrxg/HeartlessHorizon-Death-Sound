/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.transfer.item;

import java.util.Map;

import com.google.common.collect.MapMaker;
import net.fabricmc.fabric.api.transfer.v1.item.base.SingleStackStorage;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

/**
 * Wrapper around the cursor slot of a screen handler.
 */
public class CursorSlotWrapper extends SingleStackStorage {
	private static final Map<class_1703, CursorSlotWrapper> WRAPPERS = new MapMaker().weakValues().makeMap();

	public static CursorSlotWrapper get(class_1703 screenHandler) {
		return WRAPPERS.computeIfAbsent(screenHandler, CursorSlotWrapper::new);
	}

	private final class_1703 screenHandler;

	private CursorSlotWrapper(class_1703 screenHandler) {
		this.screenHandler = screenHandler;
	}

	@Override
	protected class_1799 getStack() {
		return screenHandler.method_34255();
	}

	@Override
	protected void setStack(class_1799 stack) {
		screenHandler.method_34254(stack);
	}

	@Override
	public String toString() {
		return "CursorSlotWrapper[" + screenHandler + "/" + class_7923.field_41187.method_10221(screenHandler.method_17358()) + "]";
	}
}

/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.transfer.item;

import java.util.Objects;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.base.SingleStackStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.fabricmc.fabric.impl.transfer.DebugMessages;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2589;
import net.minecraft.class_2595;
import net.minecraft.class_2609;
import net.minecraft.class_2627;
import net.minecraft.class_2745;
import net.minecraft.class_9331;

/**
 * A wrapper around a single slot of an inventory.
 * We must ensure that only one instance of this class exists for every inventory slot,
 * or the transaction logic will not work correctly.
 * This is handled by the Map in InventoryStorageImpl.
 */
class InventorySlotWrapper extends SingleStackStorage {
	/**
	 * The strong reference to the InventoryStorageImpl ensures that the weak value doesn't get GC'ed when individual slots are still being accessed.
	 */
	private final InventoryStorageImpl storage;
	final int slot;
	private final SpecialLogicInventory specialInv;
	private class_1799 lastReleasedSnapshot = null;

	InventorySlotWrapper(InventoryStorageImpl storage, int slot) {
		this.storage = storage;
		this.slot = slot;
		this.specialInv = storage.inventory instanceof SpecialLogicInventory specialInv ? specialInv : null;
	}

	@Override
	protected class_1799 getStack() {
		return storage.inventory.method_5438(slot);
	}

	@Override
	protected void setStack(class_1799 stack) {
		if (specialInv == null) {
			storage.inventory.method_5447(slot, stack);
		} else {
			specialInv.fabric_setSuppress(true);

			try {
				storage.inventory.method_5447(slot, stack);
			} finally {
				specialInv.fabric_setSuppress(false);
			}
		}
	}

	@Override
	public long insert(ItemVariant insertedVariant, long maxAmount, TransactionContext transaction) {
		if (!canInsert(slot, ((ItemVariantImpl) insertedVariant).getCachedStack())) {
			return 0;
		}

		long ret = super.insert(insertedVariant, maxAmount, transaction);
		if (specialInv != null && ret > 0) specialInv.fabric_onTransfer(slot, transaction);
		return ret;
	}

	private boolean canInsert(int slot, class_1799 stack) {
		if (storage.inventory instanceof class_2627 shulker) {
			// Shulkers override canInsert but not isValid.
			return shulker.method_5492(slot, stack, null);
		} else {
			return storage.inventory.method_5437(slot, stack);
		}
	}

	@Override
	public long extract(ItemVariant variant, long maxAmount, TransactionContext transaction) {
		long ret = super.extract(variant, maxAmount, transaction);
		if (specialInv != null && ret > 0) specialInv.fabric_onTransfer(slot, transaction);
		return ret;
	}

	/**
	 * Special cases because vanilla checks the current stack in the following functions (which it shouldn't):
	 * <ul>
	 *     <li>{@link class_2609#method_5437(int, class_1799)}.</li>
	 *     <li>{@link class_2589#method_5437(int, class_1799)}.</li>
	 * </ul>
	 */
	@Override
	public int getCapacity(ItemVariant variant) {
		// Special case to limit buckets to 1 in furnace fuel inputs.
		if (storage.inventory instanceof class_2609 && slot == 1 && variant.isOf(class_1802.field_8550)) {
			return 1;
		}

		// Special case to limit brewing stand "bottle inputs" to 1.
		if (storage.inventory instanceof class_2589 && slot < 3) {
			return 1;
		}

		return Math.min(storage.inventory.method_5444(), variant.getItem().method_7882());
	}

	// We override updateSnapshots to also schedule a markDirty call for the backing inventory.
	@Override
	public void updateSnapshots(TransactionContext transaction) {
		storage.markDirtyParticipant.updateSnapshots(transaction);
		super.updateSnapshots(transaction);

		// For chests: also schedule a markDirty call for the other half
		if (storage.inventory instanceof class_2595 chest && chest.method_11010().method_11654(class_2281.field_10770) != class_2745.field_12569) {
			class_2338 otherChestPos = chest.method_11016().method_10093(class_2281.method_9758(chest.method_11010()));

			if (chest.method_10997().method_8321(otherChestPos) instanceof class_2595 otherChest) {
				((InventoryStorageImpl) InventoryStorageImpl.of(otherChest, null)).markDirtyParticipant.updateSnapshots(transaction);
			}
		}
	}

	@Override
	protected void releaseSnapshot(class_1799 snapshot) {
		lastReleasedSnapshot = snapshot;
	}

	@Override
	protected void onFinalCommit() {
		// Try to apply the change to the original stack
		class_1799 original = lastReleasedSnapshot;
		class_1799 currentStack = getStack();

		if (storage.inventory instanceof SpecialLogicInventory specialLogicInv) {
			specialLogicInv.fabric_onFinalCommit(slot, original, currentStack);
		}

		if (!original.method_7960() && original.method_7909() == currentStack.method_7909()) {
			// Components have changed, we need to copy the stack.
			if (!Objects.equals(original.method_57380(), currentStack.method_57380())) {
				// Remove all the existing components and copy the new ones on top.
				for (class_9331<?> type : original.method_57353().method_57831()) {
					original.method_57379(type, null);
				}

				original.method_57365(currentStack.method_57353());
			}

			// None is empty and the items and components match: just update the amount, and reuse the original stack.
			original.method_7939(currentStack.method_7947());
			setStack(original);
		} else {
			// Otherwise assume everything was taken from original so empty it.
			original.method_7939(0);
		}
	}

	@Override
	public String toString() {
		return "InventorySlotWrapper[%s#%d]".formatted(DebugMessages.forInventory(storage.inventory), slot);
	}
}

package com.deathsound;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class DeathSoundMod implements ModInitializer {
    public static final String MOD_ID = "deathsound";

    public static final class_2960 CUSTOM_DEATH_SOUND_ID = class_2960.method_60655(MOD_ID, "player.death");
    public static final class_3414 CUSTOM_DEATH_SOUND = class_3414.method_47908(CUSTOM_DEATH_SOUND_ID);

    @Override
    public void onInitialize() {
        DeathSoundConfig.init();

        class_2378.method_10230(class_7923.field_41172, CUSTOM_DEATH_SOUND_ID, CUSTOM_DEATH_SOUND);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(method_9247("deathsound")
                .then(method_9247("volume")
                    .then(method_9244("percent", IntegerArgumentType.integer(0, 100))
                        .executes(context -> {
                            int percent = IntegerArgumentType.getInteger(context, "percent");
                            DeathSoundConfig.setVolumeMultiplier(percent / 100.0f);
                            context.getSource().method_9226(() ->
                                class_2561.method_43470("§aDeath sound volume set to " + percent + "%"), true);
                            return 1;
                        })
                    )
                    .executes(context -> {
                        int current = Math.round(DeathSoundConfig.getVolumeMultiplier() * 100);
                        context.getSource().method_9226(() ->
                            class_2561.method_43470("§eCurrent death sound volume: " + current + "%"), false);
                        return 1;
                    })
                )
            );
        });
    }
}

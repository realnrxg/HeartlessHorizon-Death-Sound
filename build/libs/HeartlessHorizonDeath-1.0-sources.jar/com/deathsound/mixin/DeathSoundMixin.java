package com.deathsound.mixin;

import com.deathsound.DeathSoundMod;
import net.minecraft.class_1657;
import net.minecraft.class_3414;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public class DeathSoundMixin {
    @Inject(method = "getDeathSound", at = @At("HEAD"), cancellable = true)
    private void onGetDeathSound(CallbackInfoReturnable<class_3414> cir) {
        cir.setReturnValue(DeathSoundMod.CUSTOM_DEATH_SOUND);
    }
}
